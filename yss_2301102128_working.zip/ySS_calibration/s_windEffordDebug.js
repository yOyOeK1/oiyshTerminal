var s_windEffordDebug=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Created with Inkscape (http://www.inkscape.org/) -->

<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="480"
   height="854"
   viewBox="0 0 127 225.95417"
   version="1.1"
   id="svg1600"
   inkscape:version="0.92.5 (2060ec1f9f, 2020-04-08)"
   sodipodi:docname="s_windEffordDebug.svg">
  <defs
     id="defs1594" />
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="0.5"
     inkscape:cx="521.0063"
     inkscape:cy="533.61354"
     inkscape:document-units="px"
     inkscape:current-layer="layer1"
     showgrid="false"
     units="px"
     showguides="false"
     inkscape:guide-bbox="true"
     inkscape:window-width="1366"
     inkscape:window-height="704"
     inkscape:window-x="0"
     inkscape:window-y="27"
     inkscape:window-maximized="1"
     inkscape:snap-object-midpoints="true"
     inkscape:snap-others="false">
    <sodipodi:guide
       position="60.098214,148.16667"
       orientation="1,0"
       id="guide7203"
       inkscape:locked="false" />
  </sodipodi:namedview>
  <metadata
     id="metadata1597">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:label="Layer 1"
     inkscape:groupmode="layer"
     id="layer1"
     transform="translate(0,-71.045818)">
    <rect
       style="opacity:0.66000001;fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.52000004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="recRes"
       width="112.7125"
       height="86.783333"
       x="8.9958334"
       y="76.337486"
       rx="1.2072859"
       inkscape:label="#rect844" />
    <rect
       style="opacity:0.66000001;fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.52000004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="recKalman"
       width="112.7125"
       height="86.783333"
       x="8.9958305"
       y="165.76662"
       rx="1.2072859"
       inkscape:label="#rect844" />
  </g>
</svg>`;
