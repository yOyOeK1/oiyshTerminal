var s_testFuncs=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Created with Inkscape (http://www.inkscape.org/) -->

<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:xlink="http://www.w3.org/1999/xlink"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="480"
   height="854"
   viewBox="0 0 127 225.95417"
   version="1.1"
   id="svg1600"
   inkscape:version="0.92.5 (2060ec1f9f, 2020-04-08)"
   sodipodi:docname="s_testFuncs.svg">
  <defs
     id="defs1594">
    <linearGradient
       id="linearGradient1669"
       inkscape:collect="always">
      <stop
         id="stop1673"
         offset="0"
         style="stop-color:#00ff00;stop-opacity:1;" />
      <stop
         id="stop1675"
         offset="1"
         style="stop-color:#ff0000;stop-opacity:0.953" />
    </linearGradient>
    <mask
       maskUnits="userSpaceOnUse"
       id="mask1634">
      <path
         style="opacity:1;fill:#ffffff;fill-opacity:1;stroke:none;stroke-width:3.04737902;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
         d="m 100.64088,149.00711 19.05,-0.13229 v 37.35554 h -19.05 z"
         id="path1636"
         inkscape:connector-curvature="0"
         sodipodi:nodetypes="ccccc"
         inkscape:label="#shape01" />
    </mask>
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient1669"
       id="linearGradient1671"
       x1="97.847374"
       y1="154.29811"
       x2="97.753822"
       y2="184.13876"
       gradientUnits="userSpaceOnUse" />
  </defs>
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="2.0000001"
     inkscape:cx="205.41963"
     inkscape:cy="162.44827"
     inkscape:document-units="px"
     inkscape:current-layer="layer1"
     showgrid="false"
     units="px"
     showguides="false"
     inkscape:guide-bbox="true"
     inkscape:window-width="1366"
     inkscape:window-height="704"
     inkscape:window-x="0"
     inkscape:window-y="27"
     inkscape:window-maximized="1"
     inkscape:snap-object-midpoints="true"
     inkscape:snap-others="false"
     inkscape:snap-nodes="false"
     inkscape:snap-global="false">
    <sodipodi:guide
       position="60.098214,148.16667"
       orientation="1,0"
       id="guide7203"
       inkscape:locked="false" />
  </sodipodi:namedview>
  <metadata
     id="metadata1597">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title />
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:label="Layer 1"
     inkscape:groupmode="layer"
     id="layer1"
     transform="translate(0,-71.045818)">
    <path
       sodipodi:type="star"
       style="opacity:0.474;fill:#000000;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:0.95294118"
       id="objRot2Shadow"
       sodipodi:sides="5"
       sodipodi:cx="73.525848"
       sodipodi:cy="159.48981"
       sodipodi:r1="11.301456"
       sodipodi:r2="5.6507282"
       sodipodi:arg1="1.2333403"
       sodipodi:arg2="1.8616588"
       inkscape:flatsided="false"
       inkscape:rounded="0"
       inkscape:randomized="0"
       d="m 77.267621,170.15386 -5.36228,-5.25067 -7.365339,1.44063 3.336652,-6.72238 -3.646137,-6.55968 7.424445,1.09602 5.111902,-5.49473 1.251908,7.39975 6.805466,3.16374 -6.650724,3.47729 z"
       inkscape:transform-center-x="-1.0157862"
       inkscape:transform-center-y="-0.043550668"
       transform="matrix(1.0142361,0,0,0.53534133,-0.5004691,76.22004)"
       inkscape:label="#path1724" />
    <path
       style="opacity:0.48800001;fill:#00ff00;fill-opacity:1;stroke:none;stroke-width:3.04737902;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       d="m 100.67396,149.1809 19.05,-0.13229 -0.0413,38.85209 -19.05,0.0248 z"
       id="barGreen"
       inkscape:connector-curvature="0"
       sodipodi:nodetypes="ccccc"
       inkscape:label="#shape01"
       mask="url(#mask1634)"
       transform="translate(6.0854166)" />
    <path
       style="fill:none;stroke:#000000;stroke-width:2.07007217px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="M 8.8128469,72.070628 1.0500768,72.00569 0.98538731,78.927489"
       id="path3947"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:2.07007217px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="M 1.0500768,72.00569 11.271057,81.385702"
       id="path3949"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:3.59077907px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 1.7437705,281.85526 -0.10857,13.46543 12.0066605,0.11223"
       id="path3947-0"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:3.59077907px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="M 1.6311205,295.32069 17.901801,277.59121"
       id="path3949-6"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:2.07007217px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 118.06427,296.34415 7.76277,0.0649 0.0647,-6.9218"
       id="path3947-2"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:2.07007217px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 125.82704,296.40909 -10.22098,-9.38001"
       id="path3949-61"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:3.59077907px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 125.13334,86.559513 0.10857,-13.46543 -12.00666,-0.11223"
       id="path3947-0-8"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:3.59077907px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 125.24599,73.094083 -16.27068,17.72948"
       id="path3949-6-7"
       inkscape:connector-curvature="0" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:7.05555534px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="12.160764"
       y="97.002205"
       id="text5375"><tspan
         sodipodi:role="line"
         id="tspan5373"
         x="12.160764"
         y="97.002205"
         style="stroke-width:0.26458335">test functions page.</tspan></text>
    <path
       style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 28.998744,108.6017 -0.18709,22.82482"
       id="path5377"
       inkscape:connector-curvature="0"
       sodipodi:nodetypes="cc" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:7.05555534px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="28.811655"
       y="115.89816"
       id="textDef"
       inkscape:label="#text5381"><tspan
         sodipodi:role="line"
         id="tspan5379"
         x="28.811655"
         y="115.89816"
         style="stroke-width:0.26458335">text default</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:7.05555534px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="29.100681"
       y="123.19462"
       id="textCen"
       inkscape:label="#text5385"><tspan
         sodipodi:role="line"
         id="tspan5383"
         x="29.100681"
         y="123.19462"
         style="text-align:start;text-anchor:start;stroke-width:0.26458335">text center</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:7.05555534px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="29.978136"
       y="129.36855"
       id="textRig"
       inkscape:label="#text5389"><tspan
         sodipodi:role="line"
         id="tspan5387"
         x="29.978136"
         y="129.36855"
         style="text-align:start;text-anchor:start;stroke-width:0.26458335">text right</tspan></text>
    <path
       style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 11.973675,137.60044 99.905345,-0.74835"
       id="pathBase"
       inkscape:connector-curvature="0"
       inkscape:label="#path5391" />
    <g
       id="obj2Path"
       inkscape:label="#g5396">
      <path
         inkscape:label="#path5393"
         sodipodi:open="true"
         d="m 12.054857,133.95432 a 3.6933827,3.6933827 0 0 1 3.751987,3.63036 3.6933827,3.6933827 0 0 1 -3.626892,3.75535 3.6933827,3.6933827 0 0 1 -3.7586923,-3.62342 3.6933827,3.6933827 0 0 1 3.6199423,-3.76204"
         sodipodi:end="4.6926799"
         sodipodi:start="4.6963775"
         sodipodi:ry="3.6933827"
         sodipodi:rx="3.6933827"
         sodipodi:cy="137.64723"
         sodipodi:cx="12.113991"
         sodipodi:type="arc"
         id="obj2Pathuuuu"
         style="opacity:0.525;fill:#15ff00;fill-opacity:1;stroke:#000000;stroke-width:0.15827976;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
    </g>
    <path
       sodipodi:type="star"
       style="opacity:0.525;fill:#15ff00;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="objRot"
       sodipodi:sides="5"
       sodipodi:cx="33.675961"
       sodipodi:cy="157.9931"
       sodipodi:r1="8.9822044"
       sodipodi:r2="4.4911027"
       sodipodi:arg1="0.94812554"
       sodipodi:arg2="1.5764441"
       inkscape:flatsided="false"
       inkscape:rounded="0"
       inkscape:randomized="0"
       d="m 38.914443,165.28956 -5.263847,-2.80543 -5.295199,2.7458 1.041501,-5.87315 -4.247709,-4.18753 5.90753,-0.82438 2.66997,-5.33383 2.609554,5.36365 5.897841,0.89105 -4.294737,4.13929 z"
       inkscape:transform-center-x="-0.015676694"
       inkscape:transform-center-y="-0.84280016"
       inkscape:label="#path5398" />
    <path
       sodipodi:type="star"
       style="opacity:0.525;fill:#15ff00;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="objRot2"
       sodipodi:sides="5"
       sodipodi:cx="70.345337"
       sodipodi:cy="157.05766"
       sodipodi:r1="10.591599"
       sodipodi:r2="5.2957988"
       sodipodi:arg1="0.94849346"
       sodipodi:arg2="1.576812"
       inkscape:flatsided="false"
       inkscape:rounded="0"
       inkscape:randomized="0"
       d="m 76.519264,165.66374 -6.205785,-3.31037 -6.245162,3.23547 1.230663,-6.92501 -5.006981,-4.93969 6.966375,-0.96952 3.150678,-6.28836 3.074794,6.32581 6.954207,1.05326 -5.066048,4.87909 z"
       inkscape:transform-center-x="-0.019690292"
       inkscape:transform-center-y="-0.99266243"
       inkscape:label="#path5400" />
    <path
       style="opacity:1;fill:#000000;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="objRotRC"
       sodipodi:type="arc"
       sodipodi:cx="33.629189"
       sodipodi:cy="157.29152"
       sodipodi:rx="0.51449382"
       sodipodi:ry="0.51449382"
       sodipodi:start="4.6963843"
       sodipodi:end="4.6926842"
       sodipodi:open="true"
       d="m 33.620955,156.77709 a 0.51449382,0.51449382 0 0 1 0.522654,0.50572 0.51449382,0.51449382 0 0 1 -0.505235,0.52312 0.51449382,0.51449382 0 0 1 -0.523589,-0.50475 0.51449382,0.51449382 0 0 1 0.504266,-0.52405"
       inkscape:label="#path5402" />
    <path
       style="opacity:1;fill:#000000;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="objRot2RC"
       sodipodi:type="arc"
       sodipodi:cx="64.076553"
       sodipodi:cy="166.10327"
       sodipodi:rx="0.51449382"
       sodipodi:ry="0.51449382"
       sodipodi:start="4.6963843"
       sodipodi:end="4.6926842"
       sodipodi:open="true"
       d="m 64.068319,165.58884 a 0.51449382,0.51449382 0 0 1 0.522654,0.50572 0.51449382,0.51449382 0 0 1 -0.505234,0.52312 0.51449382,0.51449382 0 0 1 -0.523589,-0.50475 0.51449382,0.51449382 0 0 1 0.504266,-0.52405"
       inkscape:label="#path5402" />
    <g
       id="g5485">
      <g
         inkscape:label="#g5396"
         id="obj2Path2"
         transform="translate(3.241844,38.998282)">
        <path
           style="opacity:0.525;fill:#15ff00;fill-opacity:1;stroke:#000000;stroke-width:0.15827976;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           id="obj2Pathuuuu-2"
           sodipodi:type="arc"
           sodipodi:cx="12.113991"
           sodipodi:cy="137.64723"
           sodipodi:rx="3.6933827"
           sodipodi:ry="3.6933827"
           sodipodi:start="4.6963775"
           sodipodi:end="4.6926799"
           d="m 12.054857,133.95432 a 3.6933827,3.6933827 0 0 1 3.751987,3.63036 3.6933827,3.6933827 0 0 1 -3.626892,3.75535 3.6933827,3.6933827 0 0 1 -3.7586923,-3.62342 3.6933827,3.6933827 0 0 1 3.6199423,-3.76204"
           sodipodi:open="true"
           inkscape:label="#path5393" />
      </g>
    </g>
    <path
       style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 15.341271,177.26324 c 0,0 -4.388057,-14.10772 -0.561266,-19.27013 2.133271,-2.87782 7.347588,-4.74808 10.369184,-2.82386 6.677364,4.2523 -1.931624,18.20274 4.036643,23.40361 5.598083,4.87828 16.729932,5.69965 22.263551,0.74836 6.01323,-5.38043 1.870887,-24.13444 1.870887,-24.13444"
       id="pathBase2"
       inkscape:connector-curvature="0"
       sodipodi:nodetypes="cssssc"
       inkscape:label="#path5481" />
    <path
       style="opacity:1;fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="path5487"
       sodipodi:type="arc"
       sodipodi:cx="32.927605"
       sodipodi:cy="215.42934"
       sodipodi:rx="16.089624"
       sodipodi:ry="16.089624"
       sodipodi:start="4.6963843"
       sodipodi:end="1.5667775"
       sodipodi:open="true"
       d="m 32.670106,199.34177 a 16.089624,16.089624 0 0 1 14.093906,7.876 16.089624,16.089624 0 0 1 0.16164,16.14445 16.089624,16.089624 0 0 1 -13.933386,8.15661" />
    <path
       style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 47.520523,215.42933 h 3.086962"
       id="path5489"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 32.646973,201.30414 -0.09354,-4.02241"
       id="path5491"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 33.114695,229.36744 -0.122428,4.20937"
       id="path5493"
       inkscape:connector-curvature="0"
       sodipodi:nodetypes="cc" />
    <g
       id="guageOne"
       inkscape:label="#g5501">
      <path
         d="m 31.351899,215.93639 a 2.5724692,2.5724692 0 0 1 2.278228,-2.83042 2.5724692,2.5724692 0 0 1 2.836194,2.27104 2.5724692,2.5724692 0 0 1 -2.263822,2.84195 2.5724692,2.5724692 0 0 1 -2.847692,-2.2566 l 2.555014,-0.29917 z"
         sodipodi:end="3.0250327"
         sodipodi:start="3.035191"
         sodipodi:ry="2.5724692"
         sodipodi:rx="2.5724692"
         sodipodi:cy="215.66319"
         sodipodi:cx="33.909821"
         sodipodi:type="arc"
         id="path5495"
         style="opacity:1;fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <path
         inkscape:connector-curvature="0"
         id="path5497"
         d="m 34.237227,212.99718 13.283296,2.43215 -13.283297,3.08696"
         style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1" />
    </g>
    <path
       style="opacity:1;fill:#000000;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="guageOneRC"
       sodipodi:type="arc"
       sodipodi:cx="33.943344"
       sodipodi:cy="215.68648"
       sodipodi:rx="0.51449382"
       sodipodi:ry="0.51449382"
       sodipodi:start="4.6963843"
       sodipodi:end="4.6926842"
       sodipodi:open="true"
       d="m 33.93511,215.17205 a 0.51449382,0.51449382 0 0 1 0.522654,0.50572 0.51449382,0.51449382 0 0 1 -0.505234,0.52312 0.51449382,0.51449382 0 0 1 -0.523589,-0.50475 0.51449382,0.51449382 0 0 1 0.504266,-0.52406"
       inkscape:label="#path5402" />
    <path
       style="opacity:1;fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="cirPath"
       sodipodi:type="arc"
       sodipodi:cx="97.660286"
       sodipodi:cy="214.68098"
       sodipodi:rx="17.586334"
       sodipodi:ry="17.586334"
       sodipodi:start="4.6963843"
       sodipodi:end="4.6668933"
       sodipodi:open="true"
       d="M 97.378834,197.0969 A 17.586334,17.586334 0 0 1 115.24181,214.2699 17.586334,17.586334 0 0 1 98.200984,232.259 17.586334,17.586334 0 0 1 80.08673,215.35126 17.586334,17.586334 0 0 1 96.86046,197.11285"
       inkscape:label="#path5518" />
    <g
       transform="translate(82.242342,20.639629)"
       id="cirPathObj"
       inkscape:label="#g5485-7">
      <g
         inkscape:label="#g5396"
         id="obj2Path2-5"
         transform="translate(3.241844,38.998282)">
        <path
           style="opacity:0.525;fill:#15ff00;fill-opacity:1;stroke:#000000;stroke-width:0.15827976;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           id="obj2Pathuuuu-2-9"
           sodipodi:type="arc"
           sodipodi:cx="12.113991"
           sodipodi:cy="137.64723"
           sodipodi:rx="3.6933827"
           sodipodi:ry="3.6933827"
           sodipodi:start="4.6963775"
           sodipodi:end="4.6926799"
           d="m 12.054857,133.95432 a 3.6933827,3.6933827 0 0 1 3.751987,3.63036 3.6933827,3.6933827 0 0 1 -3.626892,3.75535 3.6933827,3.6933827 0 0 1 -3.7586923,-3.62342 3.6933827,3.6933827 0 0 1 3.6199423,-3.76204"
           sodipodi:open="true"
           inkscape:label="#path5393" />
      </g>
    </g>
    <path
       style="opacity:1;fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="path5487-2"
       sodipodi:type="arc"
       sodipodi:cx="57.44532"
       sodipodi:cy="214.97884"
       sodipodi:rx="16.089624"
       sodipodi:ry="16.089624"
       sodipodi:start="4.6963843"
       sodipodi:end="1.5667775"
       sodipodi:open="true"
       d="m 57.187822,198.89127 a 16.089624,16.089624 0 0 1 14.093906,7.876 16.089624,16.089624 0 0 1 0.161639,16.14445 16.089624,16.089624 0 0 1 -13.933386,8.15661" />
    <path
       style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 72.038237,214.97883 h 3.086962"
       id="path5489-2"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 57.164688,200.85364 -0.09354,-4.02241"
       id="path5491-8"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 57.63241,228.91693 -0.122428,4.20937"
       id="path5493-9"
       inkscape:connector-curvature="0"
       sodipodi:nodetypes="cc" />
    <g
       id="guageTwo"
       inkscape:label="#g5583">
      <g
         inkscape:label="#g5501"
         id="uoeo"
         transform="translate(24.517716,-0.45049216)">
        <path
           style="opacity:1;fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
           id="path5495-3"
           sodipodi:type="arc"
           sodipodi:cx="33.909821"
           sodipodi:cy="215.66319"
           sodipodi:rx="2.5724692"
           sodipodi:ry="2.5724692"
           sodipodi:start="3.035191"
           sodipodi:end="3.0250327"
           d="m 31.351899,215.93639 a 2.5724692,2.5724692 0 0 1 2.278228,-2.83042 2.5724692,2.5724692 0 0 1 2.836194,2.27104 2.5724692,2.5724692 0 0 1 -2.263822,2.84195 2.5724692,2.5724692 0 0 1 -2.847692,-2.2566 l 2.555014,-0.29917 z" />
        <path
           style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
           d="m 34.237227,212.99718 13.283296,2.43215 -13.283297,3.08696"
           id="path5497-6"
           inkscape:connector-curvature="0" />
      </g>
    </g>
    <g
       id="guageTwoRC"
       inkscape:label="#g5578">
      <path
         inkscape:label="#path5402"
         d="m 58.452826,214.72155 a 0.51449382,0.51449382 0 0 1 0.522654,0.50572 0.51449382,0.51449382 0 0 1 -0.505235,0.52312 0.51449382,0.51449382 0 0 1 -0.523589,-0.50475 0.51449382,0.51449382 0 0 1 0.504266,-0.52406"
         sodipodi:open="true"
         sodipodi:end="4.6926842"
         sodipodi:start="4.6963843"
         sodipodi:ry="0.51449382"
         sodipodi:rx="0.51449382"
         sodipodi:cy="215.23598"
         sodipodi:cx="58.46106"
         sodipodi:type="arc"
         id="guageTwoRC5345"
         style="opacity:1;fill:#000000;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
    </g>
    <path
       style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 71.280782,109.4436 -0.18709,22.82482"
       id="path5377-2"
       inkscape:connector-curvature="0"
       sodipodi:nodetypes="cc" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:7.05555534px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="184.11214"
       y="-0.082522623"
       id="textOnSide"
       transform="rotate(90)"
       inkscape:label="#text5606"><tspan
         sodipodi:role="line"
         id="tspan5604"
         x="184.11214"
         y="-0.082522623"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:14.11111164px;font-family:Kalimati;-inkscape-font-specification:Kalimati;stroke-width:0.26458335">1234567890</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:10.58333397px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="25.818237"
       y="241.62175"
       id="guageOneVal"
       inkscape:label="#text1490"><tspan
         sodipodi:role="line"
         id="tspan1488"
         x="25.818237"
         y="241.62175"
         style="stroke-width:0.26458335">123</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:10.58333397px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="31.430897"
       y="81.099663"
       id="sliderVal"
       inkscape:label="#text1494"><tspan
         sodipodi:role="line"
         id="tspan1492"
         x="31.430897"
         y="81.099663"
         style="stroke-width:0.26458335">slider: 123</tspan></text>
    <path
       style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 11.777121,144.06417 99.905419,-0.74835"
       id="pathBaseAvg"
       inkscape:connector-curvature="0"
       inkscape:label="#path5391" />
    <g
       transform="translate(-0.19654776,6.4637069)"
       id="obj2PathAvg"
       inkscape:label="#g5396">
      <path
         inkscape:label="#path5393"
         sodipodi:open="true"
         d="m 12.054857,133.95432 a 3.6933827,3.6933827 0 0 1 3.751987,3.63036 3.6933827,3.6933827 0 0 1 -3.626892,3.75535 3.6933827,3.6933827 0 0 1 -3.7586923,-3.62342 3.6933827,3.6933827 0 0 1 3.6199423,-3.76204"
         sodipodi:end="4.6926799"
         sodipodi:start="4.6963775"
         sodipodi:ry="3.6933827"
         sodipodi:rx="3.6933827"
         sodipodi:cy="137.64723"
         sodipodi:cx="12.113991"
         sodipodi:type="arc"
         id="obj2Pathuuuu-4"
         style="opacity:0.525;fill:#15ff00;fill-opacity:1;stroke:#000000;stroke-width:0.15827976;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
    </g>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:4.7837739px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.11959435"
       x="33.080147"
       y="283.42633"
       id="text2227"><tspan
         sodipodi:role="line"
         id="tspan2225"
         x="33.080147"
         y="283.42633"
         style="stroke-width:0.11959435">house battery</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:6.91025448px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.17275636"
       x="67.308708"
       y="283.7233"
       id="houBatVol"
       inkscape:label="#text2231"><tspan
         sodipodi:role="line"
         id="tspan2229"
         x="67.308708"
         y="283.7233"
         style="stroke-width:0.17275636">00.00</tspan></text>
    <rect
       style="opacity:0.49300005;fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="shape02-9"
       width="20.874117"
       height="39.138367"
       x="105.67146"
       y="148.05344"
       inkscape:label="#rect1573" />
    <path
       style="fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 116.28438,148.96561 -0.26458,35.85105"
       id="barGreenPath"
       inkscape:connector-curvature="0"
       inkscape:label="#path1638" />
    <rect
       style="opacity:0.49300005;fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="shape02-9-6"
       width="13.068899"
       height="39.006062"
       x="91.030647"
       y="148.18184"
       inkscape:label="#rect1573" />
    <rect
       style="opacity:1;fill:url(#linearGradient1671);fill-opacity:1;stroke:none;stroke-width:0.5291667;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect1655"
       width="11.599497"
       height="37.511276"
       x="91.860535"
       y="149.1064"
       mask="none" />
    <path
       inkscape:connector-curvature="0"
       inkscape:label="#rect1713"
       id="barRedGreen"
       d="m 89.887741,148.53676 h 15.264449 v 37.15383 H 89.887741 Z"
       style="opacity:1;fill:#ffffff;fill-opacity:1;stroke:#ffffff;stroke-width:0.51243734;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:0.95294118" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="32.940624"
       y="288.40103"
       id="text1501"><tspan
         sodipodi:role="line"
         id="tspan1499"
         x="32.940624"
         y="288.40103"
         style="stroke-width:0.26458335">looper:</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="45.911858"
       y="288.46249"
       id="looperIter"
       inkscape:label="#text1505"><tspan
         sodipodi:role="line"
         id="tspan1503"
         x="45.911858"
         y="288.46249"
         style="stroke-width:0.26458335">10234</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="33.205208"
       y="292.03906"
       id="text1509"><tspan
         sodipodi:role="line"
         id="tspan1507"
         x="33.205208"
         y="292.03906"
         style="stroke-width:0.26458335">viewer battery:</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="60.457291"
       y="292.23749"
       id="batPercent"
       inkscape:label="#text1513"><tspan
         sodipodi:role="line"
         id="tspan1511"
         x="60.457291"
         y="292.23749"
         style="stroke-width:0.26458335">100%</tspan></text>
    <rect
       style="opacity:1;fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.52900004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="d3PlotLine"
       width="41.804169"
       height="35.71875"
       x="84.666695"
       y="237.46873"
       ry="1.3441284"
       inkscape:label="#rect4593" />
    <path
       style="opacity:1;fill:#00ff00;fill-opacity:1;stroke:#000000;stroke-width:0.52900004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       d="m 23.415625,245.47239 a 3.9026041,3.9026041 0 0 1 -3.902604,3.9026 3.9026041,3.9026041 0 0 1 -3.902605,-3.9026 3.9026041,3.9026041 0 0 1 3.902605,-3.9026 3.9026041,3.9026041 0 0 1 3.902604,3.9026"
       id="shaderTester"
       inkscape:connector-curvature="0" />
    <rect
       style="opacity:1;fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.52900004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="justGuage1"
       width="30.823965"
       height="34.52813"
       x="52.519783"
       y="238.65938"
       ry="1.3441284"
       inkscape:label="#rect4593" />
    <rect
       style="opacity:1;fill:none;fill-opacity:1;stroke:#000000;stroke-width:0.52900004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="justGuage2"
       width="26.193754"
       height="28.707289"
       x="25.46612"
       y="243.62007"
       ry="1.3441284"
       inkscape:label="#rect4593" />
  </g>
</svg>`;
