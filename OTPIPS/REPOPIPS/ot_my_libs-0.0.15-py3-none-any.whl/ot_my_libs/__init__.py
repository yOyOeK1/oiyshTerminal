


def ot_my_libs():
    print("(from init) oiyshTerminal - My libs in ver 0.0.14")
