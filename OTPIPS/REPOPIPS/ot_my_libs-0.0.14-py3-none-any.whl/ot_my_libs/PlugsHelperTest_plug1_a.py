
def plug():
    print("hello flom plug1")
