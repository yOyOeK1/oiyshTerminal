
import sys

def runIt():
    print("runner run it ....")
    print("with arguments:")
    print(sys.argv)

if __name__ == "__main__":
    print('runner init from ot_test_scrip1.runner ')