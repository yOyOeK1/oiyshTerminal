'''

Is only a ot_test_scrip1 of auto builder system and its a doc auto for main library

## use it as

"""python
from ot_test_scrip1 import ot_test_scrip1
ot_test_scrip1()

from ot_test_scrip1.example import *
ot_test_scrip1()
"""
'''

"""only version name of __init__ file"""
mver = "0.0.1"

def ot_test_scrip1():
    print("(from init) oiyshTerminal - at pip, [__init__ . ot_test_scrip1] in version:%s"%mver)

if __name__ == "__main__":
    print('__main__ init from ot_test_scrip1 !')