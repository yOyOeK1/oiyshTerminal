'''
Is only a ot_test_scrip1 of auto builder system and its a doc auto for example sub library
'''


"""only version name of example file"""
mverEx = "0.0.2"


otName="ot_test_scrip1"


def runner_cli():
    print("doing runner ...")

'''to do basic test from example sub lib'''
def ot_test_scrip1():
    print("(from exa) oiyshTerminal - at pip, [ot_test_scrip1] in version:%s"%mverEx)
    print("(from exa) from ...")
    try:
        from ot_test_scrip1 import ot_test_scrip1
        print("(from exa) execute it ...")
        ot_test_scrip1()
    except err:
        print(f"Error {err}")
    print("(from exa) ... DONE")


# to run set from example as
def test():
    print("-- starting test ----")
    ot_test_scrip1()
    print("-- end test ----")
