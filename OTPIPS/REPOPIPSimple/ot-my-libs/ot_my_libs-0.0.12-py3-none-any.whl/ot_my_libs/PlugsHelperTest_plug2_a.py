
def plug():
    print("hello flom plug2")

def PlugsHelperTest_plug2_a():
    plug()
    
