# oiyshTerminal - ot_auto1 at pip / python3 installable

  ot_auto1 is a ...
  
  
## is for case like

## solwe it like

## install 

## examples

## development of package - base line
  In directory of project to deploy
  ```shell
  tree ./
  ./
  ├── dist
  │   ├── ot_auto1-x.x.....
  .....
  │   └── ot_auto1-x.x.x.tar.gz
  ├── LICENSE.txt
  ├── pyproject.toml
  ├── README.md
  ├── README_xdoc.md
  └── src
      └── ot_auto1
          ├── example.py
          └── __init__.py
  ```

