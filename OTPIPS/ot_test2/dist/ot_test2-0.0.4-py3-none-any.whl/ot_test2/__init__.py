mver = "0.0.3"

def ot_test2():
    print("(from init) oiyshTerminal - at pip, test 2 in version:%s"%mver)
