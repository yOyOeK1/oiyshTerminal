mverEx = "0.0.1"

otName="test2"
otCodeVer="0.0.1"


def ot_test2():
    print("(from exa) oiyshTerminal - at pip, test 2 in version:%s"%mverEx)

# to run set from example as
def test():
    print("-- starting test ----")
    ot_test2()
    print("-- end test ----")
