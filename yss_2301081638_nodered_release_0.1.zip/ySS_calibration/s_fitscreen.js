var s_fitscreen=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Created with Inkscape (http://www.inkscape.org/) -->

<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="480"
   height="854"
   viewBox="0 0 127 225.95417"
   version="1.1"
   id="svg1600"
   inkscape:version="0.92.5 (2060ec1f9f, 2020-04-08)"
   sodipodi:docname="s_fitscreen.svg">
  <defs
     id="defs1594" />
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="1.4142136"
     inkscape:cx="359.62725"
     inkscape:cy="143.0627"
     inkscape:document-units="px"
     inkscape:current-layer="layer1"
     showgrid="false"
     units="px"
     showguides="false"
     inkscape:guide-bbox="true"
     inkscape:window-width="1366"
     inkscape:window-height="704"
     inkscape:window-x="0"
     inkscape:window-y="27"
     inkscape:window-maximized="1"
     inkscape:snap-object-midpoints="true"
     inkscape:snap-others="false">
    <sodipodi:guide
       position="60.098214,148.16667"
       orientation="1,0"
       id="guide7203"
       inkscape:locked="false" />
  </sodipodi:namedview>
  <metadata
     id="metadata1597">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:label="Layer 1"
     inkscape:groupmode="layer"
     id="layer1"
     transform="translate(0,-71.045818)">
    <path
       style="fill:none;stroke:#000000;stroke-width:2.07007217px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="M 8.8128469,72.070628 1.0500768,72.00569 0.98538731,78.927489"
       id="path3947"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:2.07007217px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="M 1.0500768,72.00569 11.271057,81.385702"
       id="path3949"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:3.59077907px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 1.7437705,281.85526 -0.10857,13.46543 12.0066605,0.11223"
       id="path3947-0"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:3.59077907px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="M 1.6311205,295.32069 17.901801,277.59121"
       id="path3949-6"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:2.07007217px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 118.06427,296.34415 7.76277,0.0649 0.0647,-6.9218"
       id="path3947-2"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:2.07007217px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 125.82704,296.40909 -10.22098,-9.38001"
       id="path3949-61"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:3.59077907px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 125.13334,86.559513 0.10857,-13.46543 -12.00666,-0.11223"
       id="path3947-0-8"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#000000;stroke-width:3.59077907px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 125.24599,73.094083 -16.27068,17.72948"
       id="path3949-6-7"
       inkscape:connector-curvature="0" />
  </g>
</svg>`;
