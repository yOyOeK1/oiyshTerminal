var s_apV3Svg=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Created with Inkscape (http://www.inkscape.org/) -->

<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:xlink="http://www.w3.org/1999/xlink"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="480"
   height="854"
   viewBox="0 0 127 225.95417"
   version="1.1"
   id="svg1600"
   inkscape:version="0.92.5 (2060ec1f9f, 2020-04-08)"
   sodipodi:docname="s_apV3Svg.svg">
  <defs
     id="defs1594">
    <filter
       inkscape:collect="always"
       style="color-interpolation-filters:sRGB"
       id="filter1048"
       x="-0.041533334"
       width="1.0830667"
       y="-0.042477272"
       height="1.0849545">
      <feGaussianBlur
         inkscape:collect="always"
         stdDeviation="0.51511065"
         id="feGaussianBlur1050" />
    </filter>
    <filter
       inkscape:collect="always"
       style="color-interpolation-filters:sRGB"
       id="filter1242"
       x="-0.062898317"
       width="1.1257966"
       y="-0.12640871"
       height="1.2528174">
      <feGaussianBlur
         inkscape:collect="always"
         stdDeviation="0.48541184"
         id="feGaussianBlur1244" />
    </filter>
    <filter
       inkscape:collect="always"
       style="color-interpolation-filters:sRGB"
       id="filter1242-1"
       x="-0.062898315"
       width="1.1257966"
       y="-0.12640871"
       height="1.2528174">
      <feGaussianBlur
         inkscape:collect="always"
         stdDeviation="0.48541184"
         id="feGaussianBlur1244-3" />
    </filter>
    <filter
       inkscape:collect="always"
       style="color-interpolation-filters:sRGB"
       id="filter1242-1-9"
       x="-0.062898315"
       width="1.1257966"
       y="-0.12640871"
       height="1.2528174">
      <feGaussianBlur
         inkscape:collect="always"
         stdDeviation="0.48541184"
         id="feGaussianBlur1244-3-9" />
    </filter>
    <filter
       inkscape:collect="always"
       style="color-interpolation-filters:sRGB"
       id="filter1242-14"
       x="-0.062898315"
       width="1.1257966"
       y="-0.12640871"
       height="1.2528174">
      <feGaussianBlur
         inkscape:collect="always"
         stdDeviation="0.48541184"
         id="feGaussianBlur1244-9" />
    </filter>
    <filter
       inkscape:collect="always"
       style="color-interpolation-filters:sRGB"
       id="filter1048-1"
       x="-0.041533332"
       width="1.0830667"
       y="-0.042477272"
       height="1.0849545">
      <feGaussianBlur
         inkscape:collect="always"
         stdDeviation="0.51511065"
         id="feGaussianBlur1050-0" />
    </filter>
    <filter
       inkscape:collect="always"
       style="color-interpolation-filters:sRGB"
       id="filter1242-1-0"
       x="-0.062898315"
       width="1.1257966"
       y="-0.12640871"
       height="1.2528174">
      <feGaussianBlur
         inkscape:collect="always"
         stdDeviation="0.48541184"
         id="feGaussianBlur1244-3-4" />
    </filter>
    <filter
       inkscape:collect="always"
       style="color-interpolation-filters:sRGB"
       id="filter1242-8"
       x="-0.062898315"
       width="1.1257966"
       y="-0.12640871"
       height="1.2528174">
      <feGaussianBlur
         inkscape:collect="always"
         stdDeviation="0.48541184"
         id="feGaussianBlur1244-0" />
    </filter>
    <filter
       inkscape:collect="always"
       style="color-interpolation-filters:sRGB"
       id="filter1048-4"
       x="-0.041533332"
       width="1.0830667"
       y="-0.042477272"
       height="1.0849545">
      <feGaussianBlur
         inkscape:collect="always"
         stdDeviation="0.51511065"
         id="feGaussianBlur1050-2" />
    </filter>
    <linearGradient
       id="linearGradient4544">
      <stop
         style="stop-color:black;stop-opacity:1;"
         offset="0"
         id="stop4546" />
      <stop
         style="stop-color:black;stop-opacity:0;"
         offset="1"
         id="stop4548" />
    </linearGradient>
  </defs>
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="2"
     inkscape:cx="116.09288"
     inkscape:cy="354.94198"
     inkscape:document-units="px"
     inkscape:current-layer="layer1"
     showgrid="false"
     units="px"
     showguides="true"
     inkscape:guide-bbox="true"
     inkscape:window-width="1366"
     inkscape:window-height="704"
     inkscape:window-x="0"
     inkscape:window-y="27"
     inkscape:window-maximized="1"
     inkscape:snap-object-midpoints="true"
     inkscape:snap-others="false"
     inkscape:snap-nodes="false"
     inkscape:snap-global="false">
    <sodipodi:guide
       position="60.098214,148.16667"
       orientation="1,0"
       id="guide7203"
       inkscape:locked="false" />
    <sodipodi:guide
       position="29.633333,136.26041"
       orientation="1,0"
       id="guide841"
       inkscape:locked="false" />
    <sodipodi:guide
       position="95.514581,133.35"
       orientation="1,0"
       id="guide843"
       inkscape:locked="false" />
    <sodipodi:guide
       position="130.96875,133.61458"
       orientation="0,1"
       id="guide871"
       inkscape:locked="false" />
    <sodipodi:guide
       position="140.75833,115.09375"
       orientation="0,1"
       id="guide873"
       inkscape:locked="false" />
    <sodipodi:guide
       position="147.6375,88.635416"
       orientation="0,1"
       id="guide875"
       inkscape:locked="false" />
    <sodipodi:guide
       position="45.243749,122.2375"
       orientation="1,0"
       id="guide919"
       inkscape:locked="false" />
    <sodipodi:guide
       position="4.7624999,106.3625"
       orientation="0,1"
       id="guide921"
       inkscape:locked="false" />
  </sodipodi:namedview>
  <metadata
     id="metadata1597">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title />
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:label="Layer 1"
     inkscape:groupmode="layer"
     id="layer1"
     transform="translate(0,-71.045818)">
    <use
       x="0"
       y="0"
       xlink:href="#use1486"
       id="use1494"
       transform="translate(32.799209)"
       width="100%"
       height="100%" />
    <use
       x="0"
       y="0"
       xlink:href="#use1488"
       id="use1496"
       transform="translate(32.799209)"
       width="100%"
       height="100%"
       onclick="" />
    <use
       x="0"
       y="0"
       xlink:href="#use1490"
       id="use1498"
       transform="translate(32.799209)"
       width="100%"
       height="100%" />
    <use
       x="0"
       y="0"
       xlink:href="#use1492"
       id="use1500"
       transform="translate(32.799209)"
       width="100%"
       height="100%" />
    <use
       x="0"
       y="0"
       xlink:href="#use1478"
       id="use1486"
       transform="matrix(1.0036507,0,0,0.88413157,-33.275184,-4.7503162)"
       width="100%"
       height="100%" />
    <use
       x="0"
       y="0"
       xlink:href="#use1480"
       id="use1488"
       transform="matrix(1.0036507,0,0,0.88413157,-33.275184,-4.7503162)"
       width="100%"
       height="100%"
       onclick="" />
    <use
       x="0"
       y="0"
       xlink:href="#use1482"
       id="use1490"
       transform="matrix(1.0036507,0,0,0.88413157,-33.275184,-4.7503162)"
       width="100%"
       height="100%" />
    <use
       x="0"
       y="0"
       xlink:href="#use1484"
       id="use1492"
       transform="matrix(1.0036507,0,0,0.88413157,-33.275184,-4.7503162)"
       width="100%"
       height="100%" />
    <use
       x="0"
       y="0"
       xlink:href="#rect923-6-9"
       id="use1478"
       transform="translate(32.799209,0.09354433)"
       width="100%"
       height="100%" />
    <use
       x="0"
       y="0"
       xlink:href="#rect923-61"
       id="use1480"
       transform="translate(32.799209,0.09354433)"
       width="100%"
       height="100%"
       onclick="" />
    <use
       x="0"
       y="0"
       xlink:href="#path1052-0"
       id="use1482"
       transform="translate(32.799209,0.09354433)"
       width="100%"
       height="100%" />
    <use
       x="0"
       y="0"
       xlink:href="#path1052-2-4"
       id="use1484"
       transform="translate(32.799209,0.09354433)"
       width="100%"
       height="100%" />
    <rect
       style="opacity:0.85700001;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.52900004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1;filter:url(#filter1048-4)"
       id="rect923-6-9"
       width="29.765623"
       height="29.104166"
       x="31.450977"
       y="207.55089"
       rx="5.1703825" />
    <rect
       style="opacity:1;fill:#c8b7b7;fill-opacity:1;stroke:#000000;stroke-width:0.52900004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect923-61"
       width="29.765623"
       height="29.104166"
       x="31.495403"
       y="206.52385"
       rx="5.1703825"
       onclick="" />
    <path
       style="fill:#ffffff;fill-opacity:1;stroke:none;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1;filter:url(#filter1242-8)"
       d="m 50.683593,207.7442 -13.84456,-0.18708 c -2.702484,-0.0677 -3.617817,1.65184 -4.490125,3.41436 l -0.187089,5.79975 1.169305,-5.3788 c 0.494597,-1.43484 2.085789,-2.41277 4.069179,-3.22728 z"
       id="path1052-0"
       inkscape:connector-curvature="0"
       sodipodi:nodetypes="ccccccc" />
    <path
       style="fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1;filter:url(#filter1242-1-0)"
       d="m 125.54526,208.84036 -13.84456,-0.18708 c -2.70248,-0.0677 -3.61782,1.65184 -4.49012,3.41436 l -0.18709,5.79975 1.1693,-5.3788 c 0.4946,-1.43484 2.08579,-2.41277 4.06918,-3.22728 z"
       id="path1052-2-4"
       inkscape:connector-curvature="0"
       sodipodi:nodetypes="ccccccc"
       transform="rotate(180,83.778681,221.79787)" />
    <rect
       style="opacity:0.85700001;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.52900004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1;filter:url(#filter1048-1)"
       id="rect923-6-7"
       width="29.765623"
       height="29.104166"
       x="-0.19635184"
       y="207.64442"
       rx="5.1703825" />
    <rect
       style="opacity:1;fill:#008000;fill-opacity:1;stroke:#000000;stroke-width:0.52900004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect923-5"
       width="29.765623"
       height="29.104166"
       x="-0.15192731"
       y="206.61739"
       rx="5.1703825"
       onclick="" />
    <path
       style="fill:#ffffff;fill-opacity:1;stroke:none;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1;filter:url(#filter1242-14)"
       d="M 19.036262,207.83774 5.1917025,207.65066 c -2.702484,-0.0677 -3.617817,1.65184 -4.49012504,3.41436 l -0.187089,5.79975 1.16930504,-5.3788 c 0.494597,-1.43484 2.085789,-2.41277 4.069179,-3.22728 z"
       id="path1052-8"
       inkscape:connector-curvature="0"
       sodipodi:nodetypes="ccccccc" />
    <path
       style="fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1;filter:url(#filter1242-1-9)"
       d="m 125.54526,208.84036 -13.84456,-0.18708 c -2.70248,-0.0677 -3.61782,1.65184 -4.49012,3.41436 l -0.18709,5.79975 1.1693,-5.3788 c 0.4946,-1.43484 2.08579,-2.41277 4.06918,-3.22728 z"
       id="path1052-2-7"
       inkscape:connector-curvature="0"
       sodipodi:nodetypes="ccccccc"
       transform="rotate(180,67.955016,221.84465)" />
    <rect
       style="opacity:0.85700001;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.52900004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1;filter:url(#filter1048)"
       id="rect923-6"
       width="29.765623"
       height="29.104166"
       x="96.528496"
       y="207.80389"
       rx="5.1703825" />
    <rect
       style="opacity:1;fill:#ff0000;fill-opacity:1;stroke:#000000;stroke-width:0.52900004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect923"
       width="29.765623"
       height="29.104168"
       x="96.572922"
       y="206.77686"
       rx="5.1703825"
       onclick="" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="63.999542"
       y="86.127068"
       id="apStatus"
       inkscape:label="#text831"><tspan
         sodipodi:role="line"
         id="tspan829"
         x="63.999542"
         y="86.127068"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:17.63888931px;font-family:LCDDotMatrix5x8;-inkscape-font-specification:LCDDotMatrix5x8;text-align:center;text-anchor:middle;stroke-width:0.26458335">STAND BY</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="61.691967"
       y="149.89165"
       id="apHDM"
       inkscape:label="#text835"><tspan
         sodipodi:role="line"
         id="tspan833"
         x="61.691967"
         y="149.89165"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:88.19444275px;font-family:'FFX LCD';-inkscape-font-specification:'FFX LCD';text-align:center;text-anchor:middle;stroke-width:0.26458335">360</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="4.7624998"
       y="224.76852"
       id="text847"><tspan
         sodipodi:role="line"
         id="tspan845"
         x="4.7624998"
         y="224.76852"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:14.11111164px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.26458335">STB</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="99.612175"
       y="224.94833"
       id="text847-9"><tspan
         sodipodi:role="line"
         id="tspan845-8"
         x="99.612175"
         y="224.94833"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:14.11111164px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.26458335">AUTO</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="38.766968"
       y="193.72069"
       id="text847-7"><tspan
         sodipodi:role="line"
         id="tspan845-2"
         x="38.766968"
         y="193.72069"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:14.11111164px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.26458335">-10</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="40.88364"
       y="224.94147"
       id="text847-8"><tspan
         sodipodi:role="line"
         id="tspan845-29"
         x="40.88364"
         y="224.94147"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:14.11111164px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.26458335">-1</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="73.956558"
       y="224.94145"
       id="text847-96"><tspan
         sodipodi:role="line"
         id="tspan845-0"
         x="73.956558"
         y="224.94145"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:14.11111164px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.26458335">+1</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="70.781555"
       y="193.72069"
       id="text847-2"><tspan
         sodipodi:role="line"
         id="tspan845-7"
         x="70.781555"
         y="193.72069"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:14.11111164px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.26458335">+10</tspan></text>
    <path
       style="fill:#ffffff;fill-opacity:1;stroke:none;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1;filter:url(#filter1242)"
       d="m 115.76111,207.99721 -13.84456,-0.18708 c -2.702484,-0.0677 -3.617817,1.65184 -4.490125,3.41436 l -0.187089,5.79975 1.169305,-5.3788 c 0.494597,-1.43484 2.085789,-2.41277 4.069179,-3.22728 z"
       id="path1052"
       inkscape:connector-curvature="0"
       sodipodi:nodetypes="ccccccc" />
    <path
       style="fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1;filter:url(#filter1242-1)"
       d="m 125.54526,208.84036 -13.84456,-0.18708 c -2.70248,-0.0677 -3.61782,1.65184 -4.49012,3.41436 l -0.18709,5.79975 1.1693,-5.3788 c 0.4946,-1.43484 2.08579,-2.41277 4.06918,-3.22728 z"
       id="path1052-2"
       inkscape:connector-curvature="0"
       sodipodi:nodetypes="ccccccc"
       transform="rotate(-180,116.31744,221.92438)" />
    <path
       style="opacity:0.075;fill:none;stroke:#000000;stroke-width:0.26458335px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="M 11.599497,167.36318 113.937,167.73735"
       id="pathRudder"
       inkscape:connector-curvature="0"
       inkscape:label="#path1521" />
    <rect
       style="opacity:1;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.52900004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rudderPos"
       width="5.4255705"
       height="8.9658365"
       x="6.4667144"
       y="164.64748"
       rx="0.70158219"
       inkscape:label="#rect1523" />
    <path
       style="fill:none;stroke:#000000;stroke-width:2.64583325;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       d="m 60.192707,160.60728 v 3.57188"
       id="path1525"
       inkscape:connector-curvature="0" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="58.762947"
       y="159.28047"
       id="text1529"><tspan
         sodipodi:role="line"
         id="tspan1527"
         x="58.762947"
         y="159.28047"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:7.05555582px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.26458335">0</tspan></text>
    <path
       style="fill:none;stroke:#000000;stroke-width:2.64583325;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       d="m 17.399246,161.09656 v 3.57188"
       id="path1525-2"
       inkscape:connector-curvature="0" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="12.794489"
       y="159.76976"
       id="text1529-2"><tspan
         sodipodi:role="line"
         id="tspan1527-0"
         x="12.794489"
         y="159.76976"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:7.05555582px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.26458335">-45</tspan></text>
    <path
       style="fill:none;stroke:#000000;stroke-width:2.64583325;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       d="m 115.24662,161.47074 v 3.57188"
       id="path1525-5"
       inkscape:connector-curvature="0" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="112.22935"
       y="160.14394"
       id="text1529-5"><tspan
         sodipodi:role="line"
         id="tspan1527-2"
         x="112.22935"
         y="160.14394"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:7.05555582px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.26458335">45</tspan></text>
    <path
       style="fill:none;stroke:#000000;stroke-width:2.64583325;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       d="m 86.434962,160.90948 v 3.57188"
       id="path1525-9"
       inkscape:connector-curvature="0" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="83.417694"
       y="159.58266"
       id="text1529-0"><tspan
         sodipodi:role="line"
         id="tspan1527-28"
         x="83.417694"
         y="159.58266"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:7.05555582px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.26458335">20</tspan></text>
    <path
       style="fill:none;stroke:#000000;stroke-width:2.64583325;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       d="m 37.417733,161.28366 v 3.57188"
       id="path1525-3"
       inkscape:connector-curvature="0" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="32.812969"
       y="159.95685"
       id="text1529-8"><tspan
         sodipodi:role="line"
         id="tspan1527-04"
         x="32.812969"
         y="159.95685"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:7.05555582px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.26458335">-20</tspan></text>
    <rect
       style="opacity:1;fill:#000000;fill-opacity:1;stroke:none;stroke-width:1.02377462;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:0.95294118"
       id="rect865"
       width="8.832839"
       height="4.8004556"
       x="-99.648926"
       y="121.95475"
       ry="1.3441277"
       transform="rotate(-90)" />
    <rect
       style="opacity:1;fill:#000000;fill-opacity:1;stroke:none;stroke-width:1.02377474;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:0.95294118"
       id="rect867"
       width="1.9461424"
       height="2.4213636"
       x="-92.013908"
       y="123.03027"
       ry="0.42997494"
       transform="rotate(-90)" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:16.4656105px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.41164026"
       x="95.130241"
       y="-122.90414"
       id="batPercent"
       transform="rotate(90)"
       inkscape:label="#text871"><tspan
         sodipodi:role="line"
         id="tspan869"
         x="95.130241"
         y="-122.90414"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:5.64444447px;font-family:Uroob;-inkscape-font-specification:Uroob;text-align:center;text-anchor:middle;fill:#ffffff;stroke-width:0.41164026">100%</tspan></text>
    <rect
       style="opacity:0;fill:#000000;fill-opacity:1;stroke:#000000;stroke-width:0.02645833;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect2208"
       width="31.485418"
       height="31.75"
       x="63.36771"
       y="205.78481"
       rx="1.2072859" />
    <g
       id="rmbBt"
       inkscape:label="#g3950">
      <use
         height="100%"
         width="100%"
         transform="translate(64.978315,0.65794753)"
         id="use1494-5"
         xlink:href="#use1486"
         y="0"
         x="0" />
      <rect
         onclick=""
         rx="5.1703825"
         y="178.79739"
         x="96.176033"
         height="25.598423"
         width="29.50104"
         id="rect923-3"
         style="opacity:1;fill:#9dff00;fill-opacity:1;stroke:#000000;stroke-width:0.52900004;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <use
         height="100%"
         width="100%"
         transform="translate(64.978315,0.65794753)"
         id="use1498-3"
         xlink:href="#use1490"
         y="0"
         x="0" />
      <use
         height="100%"
         width="100%"
         transform="translate(64.978315,0.65794753)"
         id="use1500-8"
         xlink:href="#use1492"
         y="0"
         x="0" />
      <text
         id="text847-2-3"
         y="190.14537"
         x="101.69231"
         style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
         xml:space="preserve"><tspan
           style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:14.11111164px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.26458335"
           y="190.14537"
           x="101.69231"
           id="tspan845-7-7"
           sodipodi:role="line">RMB</tspan></text>
      <text
         inkscape:label="#text847-2-3-7"
         id="textRMB"
         y="201.1869"
         x="111.12844"
         style="font-style:normal;font-weight:normal;font-size:3.52777767px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
         xml:space="preserve"><tspan
           style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:14.11111164px;font-family:Uroob;-inkscape-font-specification:Uroob;text-align:center;text-anchor:middle;stroke-width:0.26458335"
           y="201.1869"
           x="111.12844"
           id="tspan845-7-7-8"
           sodipodi:role="line">360</tspan></text>
    </g>
    <text
       xml:space="preserve"
       style="font-style:normal;font-weight:normal;font-size:5.33996677px;line-height:1.25;font-family:sans-serif;letter-spacing:0px;word-spacing:0px;fill:#000000;fill-opacity:1;stroke:none;stroke-width:0.40049756"
       x="1.9416405"
       y="255.44165"
       id="textInfoRMB"
       inkscape:label="#text3954"><tspan
         sodipodi:role="line"
         id="tspan3952"
         x="1.9416405"
         y="255.44165"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:16.01989937px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.40049756">RMB at: 190.0000 90.0000</tspan><tspan
         sodipodi:role="line"
         x="1.9416405"
         y="275.46652"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:16.01989937px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.40049756"
         id="tspan3956">To: 002</tspan><tspan
         sodipodi:role="line"
         x="1.9416405"
         y="295.49139"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:16.01989937px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.40049756"
         id="tspan3958">Rng: 120.345[NM]</tspan><tspan
         sodipodi:role="line"
         x="1.9416405"
         y="315.51627"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;font-size:16.01989937px;font-family:Uroob;-inkscape-font-specification:Uroob;stroke-width:0.40049756"
         id="tspan3960">XTE: 100.0</tspan></text>
    <use
       x="0"
       y="0"
       xlink:href="#use1478"
       id="use1486-6"
       transform="matrix(1.0036507,0,0,0.88413157,-64.737546,-4.5553815)"
       width="100%"
       height="100%" />
    <rect
       style="opacity:1;fill:#a9ff37;fill-opacity:1;stroke:#000000;stroke-width:0.52;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect2388"
       width="28.575001"
       height="24.870829"
       x="0.13229166"
       y="178.40051"
       rx="3.9192634"
       ry="3.2411458" />
    <use
       x="0"
       y="0"
       xlink:href="#use1482"
       id="use1490-9"
       transform="matrix(1.0036507,0,0,0.88413157,-64.737546,-4.5553815)"
       width="100%"
       height="100%" />
    <use
       x="0"
       y="0"
       xlink:href="#use1484"
       id="use1492-1"
       transform="matrix(1.0036507,0,0,0.88413157,-64.737546,-4.5553815)"
       width="100%"
       height="100%" />
    <path
       inkscape:connector-curvature="0"
       style="fill:#b5ab9b;fill-opacity:1;fill-rule:evenodd;stroke:#000000;stroke-width:0.36937797px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 8.9890875,185.46918 2.7051805,2.14549 -1.492512,2.23876 -2.6118978,-2.14547 c -0.5496832,1.4883 0.307699,4.108 3.7312778,2.79846 l 5.783487,4.1044 c -2.003457,2.14708 0.331491,4.15163 2.985025,2.89174 l -2.518615,-2.14548 1.305951,-1.77236 2.518614,1.77236 c 1.005698,-1.75682 -1.115964,-4.75591 -3.358154,-1.95893 l -5.970049,-4.29096 c 2.421745,-5.69488 -1.669744,-4.88146 -3.0783075,-3.63801 z"
       id="path1904"
       sodipodi:nodetypes="ccccccccccccc"
       inkscape:export-filename="/home/httpdocs/webs/turystyka_aedv/base_aedv2/icons/ico_config_256_256.png"
       inkscape:export-xdpi="331.84"
       inkscape:export-ydpi="331.84" />
    <path
       inkscape:connector-curvature="0"
       style="fill:#000000;fill-opacity:1;fill-rule:evenodd;stroke:#000000;stroke-width:0.36937797px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 16.1718,183.7901 6.063336,5.50364 c -0.342616,-1.21247 -1.623915,-2.11205 0.09328,-4.01113 l -4.664098,-3.638 z"
       id="path2793"
       sodipodi:nodetypes="ccccc"
       inkscape:export-filename="/home/httpdocs/webs/turystyka_aedv/base_aedv2/icons/ico_config_256_256.png"
       inkscape:export-xdpi="331.84"
       inkscape:export-ydpi="331.84" />
    <path
       inkscape:connector-curvature="0"
       style="fill:#d45500;fill-rule:evenodd;stroke:#000000;stroke-width:0.36937797px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
       d="m 17.757595,185.28261 -9.4214835,11.66025 1.5857952,1.11939 8.5819453,-12.21994 z"
       id="path3680"
       inkscape:export-filename="/home/httpdocs/webs/turystyka_aedv/base_aedv2/icons/ico_config_256_256.png"
       inkscape:export-xdpi="331.84"
       inkscape:export-ydpi="331.84" />
  </g>
  <g
     inkscape:groupmode="layer"
     id="layer2"
     inkscape:label="bts"
     style="display:inline;opacity:0.01799999"
     sodipodi:insensitive="true">
    <rect
       style="opacity:0.22099998;fill:#ff00ff;fill-opacity:1;stroke:none;stroke-width:0.02645833;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect2215"
       width="30.823959"
       height="31.28698"
       x="95.911461"
       y="134.80513"
       rx="1.2072859"
       onclick="apv3bt('auto')" />
    <rect
       style="opacity:0.22099998;fill:#ff00ff;fill-opacity:1;stroke:none;stroke-width:0.02645833;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect2217"
       width="31.353127"
       height="31.419271"
       x="63.566147"
       y="134.67284"
       rx="1.2072859"
       onclick="apv3bt('+1')" />
    <rect
       style="opacity:0.22099998;fill:#ff00ff;fill-opacity:1;stroke:none;stroke-width:0.02645833;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect2219"
       width="31.353127"
       height="32.014584"
       x="30.757812"
       y="134.3421"
       rx="1.2072859"
       onclick="apv3bt('-1')" />
    <rect
       style="opacity:0.22099998;fill:#ff00ff;fill-opacity:1;stroke:none;stroke-width:0.02645833;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect2221"
       width="31.154688"
       height="31.75"
       x="-1.1244792"
       y="134.4744"
       rx="1.2072859"
       onclick="apv3bt('stb')" />
    <rect
       style="opacity:0.22099998;fill:#ff00ff;fill-opacity:1;stroke:none;stroke-width:0.02645833;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect2223"
       width="32.014584"
       height="27.582813"
       x="30.294792"
       y="106.03175"
       rx="1.2072859"
       onclick="apv3bt('-10')" />
    <rect
       style="opacity:0.22099998;fill:#ff00ff;fill-opacity:1;stroke:none;stroke-width:0.02645833;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect2225"
       width="31.088543"
       height="28.045834"
       x="63.36771"
       y="105.89948"
       rx="1.2072859"
       onclick="apv3bt('+10')" />
    <rect
       transform="translate(0,-71.045819)"
       style="display:inline;opacity:0.22099998;fill:#ff00ff;fill-opacity:1;stroke:none;stroke-width:0.02645833;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect2225-9"
       width="31.088541"
       height="28.045834"
       x="95.546829"
       y="177.60333"
       rx="1.2072859"
       onclick="apv3bt('toRMB')" />
    <rect
       transform="translate(0,-71.045819)"
       style="display:inline;opacity:0.22099998;fill:#ff00ff;fill-opacity:1;stroke:none;stroke-width:0.02645833;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
       id="rect2223-0"
       width="32.014584"
       height="27.582813"
       x="-1.1675633"
       y="177.27272"
       rx="1.2072859"
       onclick="apv3bt('settings')" />
  </g>
</svg>`;
