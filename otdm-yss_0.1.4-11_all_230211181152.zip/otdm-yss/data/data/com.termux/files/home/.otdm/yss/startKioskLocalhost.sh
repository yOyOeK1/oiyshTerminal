#!/bin/bash
google-chrome --app="http://localhost:1880/yss"