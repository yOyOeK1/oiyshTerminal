# otdm-termux-wake-lock

Sets wake-lock in .bashrc so app have a chance to try to work in background.
Every time when it's on it will run termux-wake-lock from .bashrc



![](./onTermuxInNotification.png)
