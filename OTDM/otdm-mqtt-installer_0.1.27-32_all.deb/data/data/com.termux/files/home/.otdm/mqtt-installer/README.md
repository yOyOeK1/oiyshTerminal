# otdm-mqtt-installer

It will install if not installed in the system mosquitto and mosquitto-clients.
Then after installation it will try to set it up to machene settings in as in
.otdm/config.json When it's done you will have running mqtt broker.
