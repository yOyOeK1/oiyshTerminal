# otdm-cmqtt2mysql

A bridge from mqtt to mysql for storing. Implemented in C it's fast. Have option to drop topics. Buffer query to db to reduce traffic. So If you have a mqtt broker and you want to refer to data in the past or use it in grafana you need this.






