
char* replaceWord(const char* s, const char* oldW,
                  const char* newW);
