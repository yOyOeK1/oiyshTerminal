# Basic sail

![](./ico_sailboat_256_256.png)
Ma flavore of fast data visualization.

## Screenshots

![](./screen01.png)
