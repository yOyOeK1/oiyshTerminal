
echo "it's a test2'
date >> $PREFIX/test2_0.1.log
